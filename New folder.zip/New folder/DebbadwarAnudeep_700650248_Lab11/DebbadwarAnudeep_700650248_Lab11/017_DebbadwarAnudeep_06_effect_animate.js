//Anudeep Debbadwar, 11/03/2022
window.addEventListener("load",start,false);
function start(){
    console.log("event starting...");
}
$(
    function(){
        $("#animateButton").click(
            function(event){

                animatePicture();

                function animatePicture(){
                    $("#mypic").animate({height:586}, "slow");
                    $("#mypic").animate({width:542}, "slow");

                    $("#picdiv").css("background-color", "pink");

                    $("#mypic").animate({height:146, width:135}, "slow");
                    
                    $("#mypic").animate({height:146}, "slow");
                    $("#mypic").animate({width:271}, "slow", animatePicture());

                }

            }
            
        );


        $("#stopButton").click(
            function(event){
                $("#mypic").stop(1000);
                $("#picdiv").stop(1000);

            }
            
        );
    

    }
);

