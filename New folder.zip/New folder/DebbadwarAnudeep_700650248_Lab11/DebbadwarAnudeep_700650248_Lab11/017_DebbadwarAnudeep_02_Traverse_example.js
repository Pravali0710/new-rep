//Anudeep Debbadwar, 11/03/2022
window.addEventListener("load", start, false);

function start(){
    console.log("Event starting ....");
}

$(
    function(){
        $("#findButton").click(
            function(event){
                console.log("button click...");

                var output = "<p>";

                $buttonParent = $(this).parent().attr("id");
                console.log("buttonParent=" + $buttonParent);
                output += "parent id of button is " +$buttonParent + "<br>";

                $buttonChild = $("#deep").parent().attr("id");
                output += "parent id of deep is " +$buttonChild + "<br>";

                
                output += "</p>";
                $("#results").html(output);

            }
        );
    }
);
