//Anudeep Debbadwar, 11/03/2022
window.addEventListener("load", start, false);

function start(){
    console.log("Event starting ....");
}

jQuery(document).ready(
    function (){
        console.log("Event starting ....");
    }
);
