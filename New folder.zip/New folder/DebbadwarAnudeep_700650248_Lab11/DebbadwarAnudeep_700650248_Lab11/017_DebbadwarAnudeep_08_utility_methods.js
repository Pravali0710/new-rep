window.addEventListener("load", start, false)


function start() {
    console.log("event started")
}

$(
    function() {
        var output = "<p>"

        var mydata = "      lets wait for something big   "
        mydata = $.trim(mydata);
        output += mydata + "<br>";

        output += $.now() + "<br>";

        var quote = $("quote");
        $.data(
            quote, "metadata1" , {
                first: 100, 
                last: "veda"
            }
        );

            var metadataFirst = $.data(quote, "metadata1").first;
            var metadatalast = $.data(quote, "metadata1").first;

            output +=metadataFirst + "<br>";
            output += metadatalast + "<br>";


            output += "<p>"
        $("#results").html(output);
    }

);