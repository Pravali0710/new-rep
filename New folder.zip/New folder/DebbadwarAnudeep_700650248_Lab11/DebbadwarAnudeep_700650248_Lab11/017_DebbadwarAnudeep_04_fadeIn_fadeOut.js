//Anudeep Debbadwar, 11/03/2022
window.addEventListener("load",start,false);
function start(){
    console.log("event starting...");
}
$(
    function(){
        $("#fadeInButton").click(
            function(event){
                $("#mypic").fadeIn(1000);

            }
            
        );
        $("#fadeOutButton").click(
            function(event){
                $("#mypic").fadeOut(1000);

            }
            
        );
        $("#fadeToggleButton").click(
            function(event){
                $("#mypic").fadeToggle(1000);

            }
            
        );

    }
);

