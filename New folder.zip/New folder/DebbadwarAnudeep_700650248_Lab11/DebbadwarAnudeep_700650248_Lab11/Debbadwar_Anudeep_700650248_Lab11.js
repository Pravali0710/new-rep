/* Anudeep Debbadwar 11/04/2022 */
window.addEventListener( "load", start, false );

function start() {
	console.log ("event starting...");
    registerListeners()
}


function registerListeners() {
    document.getElementById("all").addEventListener(
        "click", function () { getfunction("all.xml"); }, false);

    document.getElementById("Debbadwar1").addEventListener(
        "click", function () { getfunction("Debbadwar1.xml"); }, false);

    document.getElementById("Debbadwar2").addEventListener(
        "click", function () { getfunction("Debbadwar2.xml"); }, false);

    document.getElementById("Debbadwar3").addEventListener(
        "click", function () { getfunction("Debbadwar3.xml"); }, false);

    document.getElementById("none").addEventListener("click", clearfunction, false);
}

function getfunction(url){
    $.ajax(
        {
            type: "GET",
            url: url,
            dataType: "xml",
            success: handleXML,
            error: handleError
        }
    );
    
}
function handleXML(xml){
    console.log("handleXML event starting...xml=" +xml);

    clearfunction();
    var output = document.getElementById("contentArea");
    var imageParagraph = document.createElement("p");

    $(xml).find('picture').each(
        function(){
            var imageName = document.createElement("img");
            var linebreak = document.createElement("br");
            var imageSpan = document.createElement("span");

            var image = $(this).find('image').text();
            var title = $(this).find('title').text();
            var width = $(this).find('width').text();
            var height = $(this).find('height').text();
            console.log("handling picture: " + image);

            imageName.setAttribute("src", image);
            imageName.setAttribute("width", width);
            imageName.setAttribute("height", height);

            imageParagraph.appendChild(imageName);
            imageParagraph.appendChild(linebreak);

            var txt = document.createTextNode(title);
            imageSpan.appendChild(txt);
            imageParagraph.appendChild(imageSpan);
            imageParagraph.appendChild(linebreak);
        }
    );

    output.appendChild(imageParagraph);

}
function clearfunction(){
    $("#contentArea").text("");
}

function handleError(){

}

$(
    function(){
        $("#fadeButton").click(
            function(event){
                $("#results").toggle(3000);
            }
        )

    }
);
