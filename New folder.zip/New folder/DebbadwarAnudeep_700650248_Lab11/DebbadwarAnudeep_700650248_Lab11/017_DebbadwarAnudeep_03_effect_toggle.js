//Anudeep Debbadwar, 11/03/2022
window.addEventListener("load", start, false);

function start(){
    console.log("Event starting ....");
}

$(
    function(){
        $("#toggleButton").click(
            function(event){
                $("#results").toggle(5000);
            }
        )

    }
);


