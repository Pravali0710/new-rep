//Anudeep Debbadwar, 11/03/2022
window.addEventListener("load", start, false);

function start(){
    console.log("Event starting ....");
}

$(
    function(){

        //hide button event
        $("#hideButton").click(
            function(event){
                $("#results").hide(3000);
                $("#anudeep").hide(3000);
                $(this).hide(5000);
            }
        );

        $(
            function(){
        
                //show button click event
                $("#showButton").click(
                    function(event){
                        $("#results").show(3000);
                        $("#anudeep").show(3000);
                        $("#hideButton").show(5000);
                    }
                )
            }
        );
    }
);


