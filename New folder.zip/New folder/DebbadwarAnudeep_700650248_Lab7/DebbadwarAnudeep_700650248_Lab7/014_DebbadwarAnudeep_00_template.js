//Anudeep Debbadwar, 09/29/2022
window.addEventListener("load", start, false);

function start(){
    console.log("Event starting ....")
}
