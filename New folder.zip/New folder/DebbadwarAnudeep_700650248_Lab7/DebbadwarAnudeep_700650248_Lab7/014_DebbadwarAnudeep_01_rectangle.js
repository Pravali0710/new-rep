//Anudeep Debbadwar, 09/29/2022
window.addEventListener("load", start, false);

function start(){
    console.log("Event starting ....")
    drawRectangle();
}
function drawRectangle(){
    console.log("drawRectangle starting...");
    var canvas = document.getElementById("drawRectangle");
    var context = canvas.getContext("2d");
    context.fillstyle="yellow";

    context.fillRect(5,10,200,75);
    context.strokeStyle="royalblue";
    context.lineWidth=6;

    context.strokeRect(4,9,201,76);
}
