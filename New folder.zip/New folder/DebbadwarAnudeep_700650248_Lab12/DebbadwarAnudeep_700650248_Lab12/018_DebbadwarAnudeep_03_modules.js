//Anudeep Debbadwar, 11/03/2022
window.addEventListener("load", start, false);

function start(){
    console.log("Event starting ....");
}

import Student from './Student.js'
import S from './Student2.js'
//import S2, {printStudent, printID}  from './Student.js'
//import S2, {printStudent as printName, printID as printIdentity}  from './Student.js'
$(
    function() {
        //populating current time
        var output = "<p>";
        var timInMilisconds = $.now();
        //call in new version: new Date().getTime() instead of $.now()
        var date = new Date(timInMilisconds);
        output += date +"<br>";

        const student = new Student("Anudeep", 700650248)
        output += "student=" +student.name + "<br>";

        const student2 = new S("Debbadwar", 700650248)
        output += "student2=" +student2.name + "<br>";



        $("#details").html(output);
    }
);
