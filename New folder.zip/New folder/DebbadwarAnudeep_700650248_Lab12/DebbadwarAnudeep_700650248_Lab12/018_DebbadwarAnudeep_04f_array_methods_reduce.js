//Anudeep Debbadwar, 11/03/2022
window.addEventListener("load", start, false);

function start(){
    console.log("Event starting ....");
}

const books  = [
    {name: 'secret', writer: 'anudeep', price: 40.99},
    {name: 'Love', writer: 'Mario', price: 30.99},
    {name: 'Hate', writer: 'octavio', price: 35.99},
    {name: 'happy', writer: 'Nicolai', price: 25.99},
    {name: 'Father', writer: 'Ivan', price: 15.99},
    {name: 'geetanjali', writer: 'tagor', price: 20.99},
    {name: 'the prophet', writer: 'gibran', price: 10.99}
];

$(
    function() {
        console.log("Jquery block starting...");
        var output = "<p>";
        
        output += "Data Output:<br>";

        const totalPrice=books.reduce((runningTotal, book)=>{
           return book.price + runningTotal
        },0)

        console.log("totalPrice=" +totalPrice);
        
        output+="</p>";
        $("#details").html(output);
    }
);
