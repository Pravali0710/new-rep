//Anudeep Debbadwar, 700650248
class Movie {
    constructor(name,director,yearRelease,rating){
        this.name = name
        this.director = director
        this.yearRelease = yearRelease
        this.rating = rating

    }

    getName(){
        return this.name;
    }

    getDirector(){
        return this.director;

    }

    getYearRelease(){
        return this.yearRelease;

    }

    getRating(){
        return this.rating;

    }
        
}

export default Movie