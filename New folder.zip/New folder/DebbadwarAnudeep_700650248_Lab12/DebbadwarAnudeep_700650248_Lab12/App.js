import logo from './Anudeep3.JPG';
import './App.css';
import { useState } from 'react';

const App  = ()  => {

const author = 'Anudeep Debbadwar'
const [counter, setCounter] = useState(0)


  return (
    <div className="App">
    <img src={logo} className="App-logo" alt="logo" />

    <h1>Welcome to {author}'s' car count</h1>

    <button onClick={() => setCounter((prevCount)=>prevCount-1) }>-</button>
    <h1>{counter}</h1>
    <button onClick={() => setCounter((prevCount)=>prevCount+1) }>+</button>



    </div>
  );
}

export default App;
