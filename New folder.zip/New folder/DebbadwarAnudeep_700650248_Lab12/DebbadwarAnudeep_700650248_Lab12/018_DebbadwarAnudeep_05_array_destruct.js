//Anudeep Debbadwar, 11/03/2022
window.addEventListener("load", start, false);

function start(){
    console.log("Event starting ....");
}

const food=['Biryani', 'Pulao' ,'korma', 'Firni', 'Faluda', 'Gulabjam'];
const luckyNumbers = [56,55,58,63,98,12,23,25];

$(
    function() {
        console.log("Jquery block starting...");
        var output = "<p>";
        
        output += "Data Output:<br>";

        const food1 = food[0]
        console.log("food1=" +food1);

        const food2 = food[1]
        console.log("food2=" +food2);

        const [a, , b] = food;
        console.log("a=" +a);
        console.log("b=" +b);



        
        
        output+="</p>";
        $("#details").html(output);
    }
);
