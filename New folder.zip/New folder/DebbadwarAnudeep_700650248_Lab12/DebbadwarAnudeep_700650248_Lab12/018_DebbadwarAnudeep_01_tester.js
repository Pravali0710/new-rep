//Anudeep Debbadwar, 11/03/2022
window.addEventListener("load", start, false);

function start(){
    console.log("Event starting ....");
}

$(
    function() {
        //populating current time
        var output = "<p>";
        var timInMilisconds = $.now();
        //call in new version: new Date().getTime() instead of $.now()
        var date = new Date(timInMilisconds);
        output += date +"<br>";

        var anudeep = new student("ANudeep Debbadwar");
        var name= anudeep.getName();
        var type = anudeep instanceof student;
        output += "Name:" + name + ", type: " +type + "<br>";

        let deep = new Teacher("Anudeep");
        let teacherName = deep.getName();
        let deepType = deep instanceof Teacher;
        let deepTypeObj = deep instanceof Object;
        output+="Name:"+teacherName+",type:"+deepType+",deepTypeObj:"+deepTypeObj+"<br>";


        $("#details").html(output);
    }
);
