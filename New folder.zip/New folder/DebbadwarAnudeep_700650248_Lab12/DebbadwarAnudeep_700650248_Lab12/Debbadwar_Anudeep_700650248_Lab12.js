//Anudeep Debbadwar, 12/01/2022
window.addEventListener("load", start, false);

function start(){
    console.log("Event starting ....");
}

import Movie from './Movie.js'


$(
    function() {
        var output = "<p>";

        output +="<br>";

        const movie = new Movie("Business Man", "Puri", 2012,"R")
        const movie2 = new Movie("Avatar", "Cameron", 2011,"R")
        const movie3 = new Movie("The Lover", "Jean-Jacques", 1992,"NC-17")
        var arr=[movie,movie2,movie3]
        output += "Movie List: <br><br>";
        output+="<table style='border:1px solid black'><th style='border:1px solid black'>Name</th>"+
        "<th style='border:1px solid black'>Director</th><th style='border:1px solid black'>Year</th><th style='border:1px solid black'>Rating</th>";
        for (var i=0;i<3;i++)
        {
        output+="<tr style='border:1px solid black'>"
        output += "<td style='border:1px solid black'>" +arr[i].getName()+"</td>"
        +"<td style='border:1px solid black'>"+arr[i].getDirector()+"</td>"
        +"<td style='border:1px solid black'>"+arr[i].getYearRelease()+"</td>"
        +"<td style='border:1px solid black'>"+arr[i].getRating()+"</td>";
        output+="</tr>"
        }
        output+="</table>"
        $("#details").html(output);
    }
);
