class Student {
    constructor(name,id){
        this.name=name
        this.id=id
    }
}

function printStudent(student){
    return student.name

}

function printID(student){
    return student.id
}

export default Student
export {printStudent,printID}