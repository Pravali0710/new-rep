//Anudeep Debbadwar, 11/03/2022
window.addEventListener("load", start, false);

function start(){
    console.log("Event starting ....");
}


const luckyNumbers = [56,55,58,63,98,12,23,25];

$(
    function() {
        console.log("Jquery block starting...");
        var output = "<p>";
        
        output += "Data Output:<br>";

        const numIncludes = luckyNumbers.includes(55);


        console.log("numIncludes=" +numIncludes);
        
        output+="</p>";
        $("#details").html(output);
    }
);
