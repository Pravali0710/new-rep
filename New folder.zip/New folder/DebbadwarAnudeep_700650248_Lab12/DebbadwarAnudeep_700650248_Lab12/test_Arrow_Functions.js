//named function with multiple parameters
function add(x,y){
    return x+y;
}

let add2 = (x,y) =>  x+y; 

//function with 1 param
function isNumberObject(x){
    return x instanceof Number;

}

let isNumberObject2 =(x) => x instanceof Number;

//function without param
function generateRandomNumber(){
    return Math.random();
}

let generateRandomNumber2 =()=>  Math.random();

//anonymous function
document.addEventListener('click', 
function(){
    console.log('click event happened');

  }
);

document.addEventListener('click', ()=>console.log('click event happened 2'));