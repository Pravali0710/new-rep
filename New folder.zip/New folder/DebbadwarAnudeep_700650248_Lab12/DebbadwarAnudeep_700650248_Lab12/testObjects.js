//pre-ES6
function student(name){
    this.name = name
}

student.prototype.getName = function(){
    return this.name
}

//ES6 version using class keyword
class Teacher {
    constructor(name){
        this.name = name

    }

    getName (){
        return this.name;

    }
        
}
