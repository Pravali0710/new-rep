//Anudeep Debbadwar, 11/03/2022
window.addEventListener("load", start, false);

function start(){
    console.log("Event starting ....");
}

const studentOne = {
    name: 'anudeep',
    year:2022,
    gpa: 3.75,
    enrollment: {
        subject:'client side',
        code:5611
    }
} 

const studentTwo = {
    name: 'Rahul',
    year:2023,
   gpa: 3.79,
    
} 

$(
    function() {
        console.log("jQuery block starting...");
        var output = "<p>";
        
        output += "Data Output:<br>";

        const {name, year} = studentOne
        console.log("name=" + name);

        const {name:firstName, year:gradyear} = studentOne
        console.log("firstName=" + firstName);

        const {name:fName, year:gyear, gpa=4.0} = studentOne
        console.log("fName=" + firstName + ", gpa=" + gpa);
        
        const {name:fN, ...details} = studentOne
        console.log("fN=" + fN + ", details=" + details);

        const {name:f1, enrollment: {subject} } = studentOne
        console.log("f1=" + f1 + ", subject=" + subject);
        
        const studentThree = {...studentOne, ...studentTwo}
        console.log (studentThree);

        output += "</p>";
        $("#details").html(output);
    }
);
