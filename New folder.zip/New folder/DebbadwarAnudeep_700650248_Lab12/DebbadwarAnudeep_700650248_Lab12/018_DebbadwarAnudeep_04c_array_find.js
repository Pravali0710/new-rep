//Anudeep Debbadwar, 11/03/2022
window.addEventListener("load", start, false);

function start(){
    console.log("Event starting ....");
}

const books  = [
    {name: 'secret', writer: 'anudeep', price: 40.99},
    {name: 'Love', writer: 'Mario', price: 30.99},
    {name: 'Hate', writer: 'octavio', price: 35.99},
    {name: 'happy', writer: 'Nicolai', price: 25.99},
    {name: 'Father', writer: 'Ivan', price: 15.99},
    {name: 'geetanjali', writer: 'tagor', price: 20.99},
    {name: 'the prophet', writer: 'gibran', price: 10.99}
];

$ (
	function () {
		var output = "<p>";
		var timInMilisconds = $.now();
		var date = new Date(timInMilisconds);
		output += date + "<br>";

		const bookFind = books.find ( (book) => {
			return book.name == "geetanjali"
		});
		console.log ("bookFind=" + JSON.stringify(bookFind));
		
		
		output += "</p>";
		$("#details").html(output);
	}
);