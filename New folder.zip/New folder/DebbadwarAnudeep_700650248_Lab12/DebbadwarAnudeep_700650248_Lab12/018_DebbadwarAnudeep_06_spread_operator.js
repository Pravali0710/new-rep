//Anudeep Debbadwar, 11/03/2022
window.addEventListener("load", start, false);

function start(){
    console.log("Event starting ....");
}

const food=['Biryani', 'Pulao' ,'korma', 'Firni', 'Faluda', 'Gulabjam'];
const luckyNumbers = [56,55,58,63,98,12,23,25];

$(
    function() {
        console.log("Jquery block starting...");
        var output = "<p>";
        output += "Data Output:<br>";

        const [b, , k, ...misti] = food
        console.log("misti="+ misti);

        const foodAndLuckyNums = [...food,...luckyNumbers]
        console.log("foodAndLuckyNums="+ foodAndLuckyNums);

        
        output+="</p>";
        $("#details").html(output);
    }
);
