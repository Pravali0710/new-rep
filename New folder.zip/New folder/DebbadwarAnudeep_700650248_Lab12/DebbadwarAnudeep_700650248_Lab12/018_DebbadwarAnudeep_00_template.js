//Anudeep Debbadwar, 11/03/2022
window.addEventListener("load", start, false);

function start(){
    console.log("Event starting ....");
}

$(
    function() {
        var output = "<p>";
        var timInMilisconds = $.now();
        var date = new Date(timInMilisconds);
        output += date +"<br>";
        $("#details").html(output);
    }
);
