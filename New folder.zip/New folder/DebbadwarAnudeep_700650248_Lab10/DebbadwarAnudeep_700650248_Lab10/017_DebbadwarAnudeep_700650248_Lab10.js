//Anudeep Debbadwar, 10/27/2022

window.addEventListener( "load", start, false );

function start() {
console.log ("main load event starting...");
registerListeners();
}

function registerListeners() {
    document.getElementById( "all" ).addEventListener("click", function() { getImages("all.json"); },false);
    document.getElementById( "hatshepsut" ).addEventListener("click", function() { getImages("Debbadwar1.json"); },false);
    document.getElementById( "cleopatra" ).addEventListener("click", function() { getImages("Debbadwar2.json");},false); 
    document.getElementById( "inanna" ).addEventListener("click", function() { getImages("Debbadwar3.json");},false); 
    document.getElementById( "none" ).addEventListener("click", clearImages, false );
    }

    function getImages( url ) {
    console.log("getImages starting with URL=" + url);
    $(
        $.getJSON(url, loadJSONData)
    );
        }

        function loadJSONData(myJSONobj) {
            console.log ("load SONData starting with my soNoby=" + myJSONobj); 
            clearImages (); // prepare to display a new set of images
            // get the placeholder div element named details
            var output = document.getElementById( "details" );
            var imageParagraph = document.createElement ( "p" );
            
            for (var i=0; i < myJSONobj.pictures.picture.length; i++) {
            for (var i=0; i < myJSONobj.pictures.picture.length; i++) {
            console.log ("loop " + i);

            var image = myJSONobj.pictures.picture[i].image
            var title = myJSONobj.pictures.picture[i].title;
            var width = myJSONobj.pictures.picture[i].width;
            var height = myJSONobj.pictures.picture[i].height;

            var imageName = document.createElement( "img" );
            var linebreak = document.createElement( "br" );
            var imageSpan = document.createElement( "span" );

            imageName.setAttribute( "src", image ); 
            imageName.setAttribute( "width", width); 
            imageName.setAttribute( "height", height );

            imageParagraph.appendChild( imageName ); 
            imageParagraph.appendChild( linebreak );

            var txt = document.createTextNode(title);
            imageSpan.appendChild(txt);
            imageParagraph.appendChild( imageSpan); 
            imageParagraph.appendChild( linebreak );

        }
        output.appendChild(imageParagraph);
    }
    }
    function clearImages(){
        $('#details').text("");
    }


