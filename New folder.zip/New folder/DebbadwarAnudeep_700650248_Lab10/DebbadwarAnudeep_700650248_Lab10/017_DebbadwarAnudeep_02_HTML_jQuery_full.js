//Anudeep Debbadwar , 10/27/2022

window.addEventListener("load", start, false);

function start(){
    console.log("Event starting ....");
    registerListeners();
}

var asyncRequest; 
function registerListeners()
{
    var img;
    img = document.getElementById( "debbadwar1" );
    img.addEventListener( "mouseover",function(){ getContent( "Debbadwar1.html" ); }, false );
    img.addEventListener( "mouseout", clearContent, false );

    img = document.getElementById( "debbadwar2" );
    img.addEventListener( "mouseover",
    function() { getContent( "Debbadwar2.html" ); }, false );
    img.addEventListener( "mouseout", clearContent, false );

    img = document.getElementById( "debbadwar3" );
    img.addEventListener( "mouseover",
    function() { getContent( "Debbadwar3.html" ); }, false );
    img.addEventListener( "mouseout", clearContent, false );
} 

function getContent( url ) {

    $(
    function() {
        $("#contentArea").load(url);
    }
    );
}
function clearContent() {
    $(
        function(){
        $("#contentArea").text("");
        }
    );
}

/*

    function getContent( url ){
    try {
    asyncRequest = new XMLHttpRequest(); 
    asyncRequest.addEventListener("readystatechange", stateChange, false);
    asyncRequest.open( "GET", url, true ); 
    asyncRequest.send( null ); 
    }
    catch ( exception ){
    alert( "Request failed." );
    } 
    } 
    function stateChange(){
    if (asyncRequest.readyState == 4 && asyncRequest.status == 200 ) {
    document.getElementById( "contentArea" ).innerHTML = asyncRequest.responseText; 
    } 
    }
    function clearContent(){
    document.getElementById( "contentArea" ).innerHTML = "";
    } 
    window.addEventListener( "load", registerListeners, false );
    */