//Anudeep Debbadwar , 10/27/2022

window.addEventListener( "load", start, false );

function start() {
console.log ("main load event starting...");
registerListeners();
}

var asyncRequest; // variable to hold XMLHttpRequest object

//register event listenes
function registerListeners() {
document.getElementById( "all" ).addEventListener("click", function() { getImages( "all.xml"); },false);
document.getElementById( "hatshepsut" ).addEventListener("click", function() { getImages("Debbadwar1.xml"); },false);
document.getElementById( "cleopatra" ).addEventListener("click", function() { getImages("Debbadwar2.xml");},false); 
document.getElementById( "inanna" ).addEventListener("click", function() { getImages( "Debbadwar3.xml");},false); 
document.getElementById( "none" ).addEventListener("click", clearImages, false );
}

function getImages(url){
    try{
        asyncRequest = new XMLHttpRequest (); // create request object
// register event handler
asyncRequest.addEventListener("readystatechange", processResponse, false);
asyncRequest.open( "GET", url, true ); // prepare the request
asyncRequest.send( null); // send the request
}

catch ( exception) {
alert ( "Request Failed: " + exception);
}
}

function processResponse(){
    if ( asyncRequest.readyState == 4 && asyncRequest.status == 200 && asyncRequest.responseXML ){
    clearImages (); // prepare to display a new set of images
    // get the placeholder div element named details
    var output = document.getElementById( "details" );
    var imageParagraph = document.createElement ( "p" );
    // get the pictures from the responseXML
    var pictures = asyncRequest.responseXML.getElementsByTagName ("picture" )
    // place images in unordered list
    for ( var i = 0; i < pictures.length; ++i) {
    var picture = pictures.item( i );
    var image = picture.getElementsByTagName( "image" ).item( 0 ).firstChild.nodeValue;
    var title = picture.getElementsByTagName( "title" ).item( 0 ).firstChild.nodeValue;
    var width = picture.getElementsByTagName( "width" ).item( 0).firstChild.nodeValue;
    var height = picture.getElementsByTagName( "height" ).item( 0 ).firstChild.nodeValue;

    var imageName = document.createElement( "img" );
    var linebreak = document.createElement( "br" );
    var imageSpan = document.createElement( "span" );
// set img element's sc attribute
imageName.setAttribute( "src", image ); 
imageName.setAttribute( "width", width); 
imageName.setAttribute( "height", height );

imageParagraph.appendChild( imageName ); 
imageParagraph.appendChild( linebreak );

var txt = document.createTextNode(title);
imageSpan.appendChild(txt);
imageParagraph.appendChild( imageSpan); 
imageParagraph.appendChild( linebreak );
}
    output.appendChild(imageParagraph);
}
}
function clearImages(){
    document.getElementById("details").innerHTML="";
}