//Anudeep Debbadwar, 10/27/2022
window.addEventListener("load", start, false);

function start(){
    console.log("Event starting ....");
}

jQuery(document).ready(
    function (){
        console.log("Event starting ....");
    }
);
