//Anudeep Debbadwar, 10/27/2022

window.addEventListener( "load", start, false );

function start() {
    console. log ("event starting...");
    processJSONData();
}
function processJSONData() {
console.log ("process]sonData starting...");
$(
$.getJSON("student.json", loadJSONData)
);
}
//JSON object is implicitly received when a function is calle
function loadJSONData(student) {
    var output = "<p>" 
    output +="Name:"+ student.name + "<br>"
    output += "Designation: " + student.designation + "<br>" 
    output += "Year"+ student.year + "<br>"
    output +="Cost:"+ student.cost +"<br>"
    output +="</p>"
    console.log ("output=" + output);
    $ ("#content").html(output);
}