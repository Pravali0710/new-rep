//Anudeep Debbadwar, 10/07/2022
window.addEventListener("load", start, false);

function start(){
    console.log("Event starting ....");
}

$(
    function (){
        
        $("td").click(
            function(){
                $(this).css("background-color", "yellow");
            }

        );
    }
);


