//Anudeep Debbadwar, 09/29/2022
window.addEventListener("load", start, false);

function start(){
    console.log("Event starting ....");
}

jQuery(document).ready(
    function (){
        console.log("Event starting ....");
    }
);
