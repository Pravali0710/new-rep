//Anudeep Debbadwar, 10/20/2022
window.addEventListener("load", start, false);

function start(){
    console.log("Event starting ....");
}

var asyncRequest;

function getContent(url){
    console.log("getContent starting ....");

    try {
        asyncRequest= new XMLHttpRequest();
        asyncRequest.addEventListener("readystatechange", stateChange, false);
        asyncRequest.open("GET", url, true);
        asyncRequest.send(null);

    }
    catch(exception){
        alert("failed..");

    }
}

 function stateChange(){
    if(asyncRequest.readyState==4 && asyncRequest.status==200 ){
        document.getElementById("contentArea").innerHTML = asyncRequest.responseText;


    }

 }