//Anudeep Debbadwar, 09/29/2022
window.addEventListener("load", start, false);

var studentXML = "<student>"+
"<name>Anudeep Debbadwar</name>" +
"<designation>Student</designation>" +

"</student>";

function start(){
    console.log("Event starting ....");
    loadXML();
}

function loadXML(){
    console.log("loadXML starting....");
    var xmlParser = new DOMParser();
    var myStudentXML = xmlParser.parseFromString(studentXML, "text/xml");
    var name= myStudentXML.getElementsByName("name").item(0).firstChild.nodeValue;
    var designation= myStudentXML.getElementsByName("designation").item(0).firstChild.nodeValue;
    document.getElementById("details" ).innerHTML=name + cost;
}
